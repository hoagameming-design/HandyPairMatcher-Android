# Handy Pair Matcher — Android starter (v0.1)

Native Android Studio project using Kotlin, Jetpack Compose, Media3 ExoPlayer and Android's Storage Access Framework.

## Run
1. Install Android Studio and a JDK 17-compatible Android SDK.
2. Open this **folder** as an Android Studio project; let Gradle sync.
3. Connect an Android phone with USB debugging or use Android Studio's emulator.
4. Click Run.

## Included
- Pick a video and `.funscript` with Android's system file picker.
- Remember candidate pairs across launches and keep read-only access to selected files.
- Show embedded video playback and review candidates.
- Save Correct / Offset / Wrong verdicts with confirmation; move to corresponding tabs.
- Sort candidates by manually entered estimated score.

## Not yet included
- Handy cloud connection, script upload, synchronized playback or calibration.
- Automatically calculating scores, importing Windows review.csv (Windows paths do not exist on Android), bulk scanning, manual re-pair, duplicate hashing or Paired/Misc/Duplicates folder copies.
- Migration/export or backup of the local candidate database.

The app does not edit the original files. Verdicts are saved to private app preferences. Avoid uninstalling before export is added.

This source project is **not** a prebuilt APK and has **not** been compiled or device-tested in this environment. Android Studio/Gradle are needed to build it.

## Build an APK using GitHub Actions (no Android Studio required)
1. Create a new GitHub repository and upload the **contents** of this project folder (including `.github/workflows/build-apk.yml`) to the repository root.
2. In the repository's **Actions** tab, choose **Build Android debug APK** and click **Run workflow**. The workflow also runs automatically on a push to `main` or `master`.
3. When the workflow finishes, open that run and download the `HandyPairMatcher-debug-apk` artifact.
4. Unzip the downloaded artifact, then install `app-debug.apk` on your Android phone.

This is a debug/test build, not a Play Store release. The app currently supports manual file selection, video previews, verdict tabs and score sorting. It **does not** yet connect to The Handy or automatically match/copy files.

## v0.2 storage scanning

Choose a video folder and optionally a separate script folder. The app recursively scans selected folders using Android Storage Access Framework; it does not access other folders without permission. Ranking uses filename similarity and, for promising candidates, approximate duration versus last funscript action timestamp. Scores are heuristics and require manual review. No source files are changed. Very large scans are capped at 10,000 entries or 750 candidate matches. Select smaller folders if limited.
