package com.example.handypairmatcher

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Read-only scan of user-granted SAF trees. Never writes to source files. */
internal object StorageScanner {
    internal data class MediaFile(val uri: Uri, val name: String, val video: Boolean)
    internal data class Candidate(val video: MediaFile, val script: MediaFile, val score: Int)
    internal data class Result(val candidates: List<Candidate>, val videos: Int, val scripts: Int,
                               val limited: Boolean, val warnings: List<String>)
    private val videoExtensions = setOf("mp4", "mkv", "mov", "avi", "webm", "m4v")
    private const val MAX_ENTRIES = 10000
    private const val MAX_CANDIDATES = 750

    fun scan(context: Context, roots: List<Uri>): Result {
        val found = LinkedHashMap<String, MediaFile>()
        val warnings = mutableListOf<String>()
        val pending = ArrayDeque<DocumentFile>()
        roots.distinct().forEach { uri ->
            try {
                val doc = DocumentFile.fromTreeUri(context, uri)
                if (doc != null && doc.isDirectory) pending.add(doc)
                else warnings.add("Folder unavailable: $uri")
            } catch (e: Exception) { warnings.add("Folder cannot be opened: ${e.message}") }
        }
        var seen = 0
        while (pending.isNotEmpty() && seen < MAX_ENTRIES) {
            val folder = pending.removeFirst()
            val children = try { folder.listFiles() } catch (e: Exception) {
                warnings.add("Cannot read ${folder.name ?: "folder"}: ${e.message}")
                emptyArray()
            }
            for (child in children) {
                if (++seen > MAX_ENTRIES) break
                if (child.isDirectory) pending.add(child)
                else if (child.isFile) {
                    val name = child.name ?: continue
                    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    val video = ext in videoExtensions
                    if (video || ext == "funscript") found[child.uri.toString()] = MediaFile(child.uri, name, video)
                }
            }
        }
        val videos = found.values.filter { it.video }.sortedBy { it.name }
        val scripts = found.values.filterNot { it.video }.sortedBy { it.name }
        val durationCache = mutableMapOf<String, Double?>()
        val scriptTimeCache = mutableMapOf<String, Double?>()
        val candidates = mutableListOf<Candidate>()
        for (video in videos) {
            if (candidates.size >= MAX_CANDIDATES) break
            val scores = scripts.map { script ->
                val base = nameScore(video.name, script.name)
                // Only inspect action timestamps for promising candidates; scanning remains read-only.
                val score = if (base >= 20) {
                    val vd = durationCache.getOrPut(video.uri.toString()) { videoSeconds(context, video.uri) }
                    val sd = scriptTimeCache.getOrPut(script.uri.toString()) { scriptSeconds(context, script.uri) }
                    val timingBonus = if (vd != null && sd != null && vd > 0) {
                        val diff = abs(vd - sd)
                        when { diff < 3 -> 25; diff < 10 -> 15; diff < 30 -> 7; else -> 0 }
                    } else 0
                    min(100, base + timingBonus)
                } else base
                Candidate(video, script, score)
            }.sortedByDescending { it.score }.take(3).filter { it.score >= 20 }
            candidates.addAll(scores.take(MAX_CANDIDATES - candidates.size))
        }
        if (seen > MAX_ENTRIES || candidates.size == MAX_CANDIDATES) warnings.add("Scan limit reached. Choose smaller folders for more complete results.")
        return Result(candidates, videos.size, scripts.size,
            seen > MAX_ENTRIES || candidates.size == MAX_CANDIDATES, warnings)
    }

    private fun normalized(name: String): List<String> = name.substringBeforeLast('.').lowercase(Locale.ROOT)
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().split(Regex("\\s+"))
        .filter { it.isNotEmpty() && it !in setOf("video", "script", "funscript", "final", "copy") }

    private fun nameScore(a: String, b: String): Int {
        val na = normalized(a)
        val nb = normalized(b)
        if (na.isEmpty() || nb.isEmpty()) return 0
        if (na == nb) return 75
        val aa = na.toSet(); val bb = nb.toSet()
        val intersection = aa.intersect(bb).size
        val union = aa.union(bb).size
        val jaccard = if (union > 0) intersection.toDouble() / union else 0.0
        val joinedA = na.joinToString(""); val joinedB = nb.joinToString("")
        val substring = if (min(joinedA.length, joinedB.length) >= 5 &&
            (joinedA.contains(joinedB) || joinedB.contains(joinedA))) 20 else 0
        return min(75, (jaccard * 75).toInt() + substring)
    }

    private fun videoSeconds(context: Context, uri: Uri): Double? = try {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()?.div(1000)
        } finally { retriever.release() }
    } catch (_: Exception) { null }

    private fun scriptSeconds(context: Context, uri: Uri): Double? = try {
        // Avoid reading huge malformed files into memory.
        val size = context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1
        if (size > 12 * 1024 * 1024) null
        else {
            val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            val actions = JSONObject(raw ?: "{}").optJSONArray("actions")
            if (actions == null || actions.length() == 0) null
            else {
                var maxMs = 0.0
                for (i in 0 until actions.length()) {
                    val action = actions.optJSONObject(i) ?: continue
                    val t = action.optDouble("at", Double.NaN)
                    if (t.isFinite() && t >= 0) maxMs = max(maxMs, t)
                }
                maxMs / 1000
            }
        }
    } catch (_: Exception) { null }
}
