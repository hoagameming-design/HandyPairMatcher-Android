# Handy Pair Matcher — Android starter (v0.1)

Native Android Studio project using Kotlin, Jetpack Compose, Media3 ExoPlayer and Android's Storage Access Framework.

## Run
1. Install Android Studio and a JDK 17-compatible Android SDK.
2. Open this **folder** as an Android Studio project; let Gradle sync.
3. Connect an Android phone with USB debugging or use Android Studio's emulator.
4. Click Run.

## Included
- Pick a video and `.funscript` with Android's system file picker.
- Remember candidate pairs across launches and keep read-only access to selected files.
- Show embedded video playback and review candidates.
- Save Correct / Offset / Wrong verdicts with confirmation; move to corresponding tabs.
- Sort candidates by manually entered estimated score.

## Not yet included
- Handy cloud connection, script upload, synchronized playback or calibration.
- Automatically calculating scores, importing Windows review.csv (Windows paths do not exist on Android), bulk scanning, manual re-pair, duplicate hashing or Paired/Misc/Duplicates folder copies.
- Migration/export or backup of the local candidate database.

The app does not edit the original files. Verdicts are saved to private app preferences. Avoid uninstalling before export is added.

This source project is **not** a prebuilt APK and has **not** been compiled or device-tested in this environment. Android Studio/Gradle are needed to build it.

## Build an APK using GitHub Actions (no Android Studio required)
1. Create a new GitHub repository and upload the **contents** of this project folder (including `.github/workflows/build-apk.yml`) to the repository root.
2. In the repository's **Actions** tab, choose **Build Android debug APK** and click **Run workflow**. The workflow also runs automatically on a push to `main` or `master`.
3. When the workflow finishes, open that run and download the `HandyPairMatcher-debug-apk` artifact.
4. Unzip the downloaded artifact, then install `app-debug.apk` on your Android phone.

This is a debug/test build, not a Play Store release. The app currently supports manual file selection, video previews, verdict tabs and score sorting. It **does not** yet connect to The Handy or automatically match/copy files.

## v0.2 storage scanning

Choose a video folder and optionally a separate script folder. The app recursively scans selected folders using Android Storage Access Framework; it does not access other folders without permission. Ranking uses filename similarity and, for promising candidates, approximate duration versus last funscript action timestamp. Scores are heuristics and require manual review. No source files are changed. Very large scans are capped at 10,000 entries or 750 candidate matches. Select smaller folders if limited.

## Version 0.3 - Original Handy test player

From Review, open a candidate and enter your connection key. Connect while the original Handy is in Wi-Fi online mode, choose Prepare script, then Play + sync. Use Pause, +/-10s and Offset (milliseconds) to assess the pairing. Saving Correct / Offset / Wrong remains supported. The selected MP4 is played locally by Media3 and is not uploaded; the `.funscript` actions are uploaded to HandyFeeling's script service by the official Ohdoki SDK when you choose Prepare. An internet connection is required for cloud synchronization. The connection key is kept only in a temporary in-memory SDK store; it is not saved to Android preferences or pair verdicts.

This is a first Android integration and has **not been tested with a physical Handy**. Synchronization behavior depends on firmware, network latency and SDK CDN access. Test carefully at reduced movement range. For best results use the explicit Play + sync / Pause / +/-10s controls rather than Android hardware media commands.

## v0.4 Scan performance changes
- One SAF query per directory rather than multiple `DocumentFile` calls per entry.
- Script filename token index for faster candidate lookup in large collections.
- Read video/script timing metadata for only five strong initial matches per video, capped at 900 pairs per scan.
- Cache durations for unchanged files when storage provider exposes size and modification time; reused across launches.
- All scanning is read-only. Scan limits are safety caps, not full coverage guarantees.
- Fast mode deliberately may miss pairs with completely unrelated filenames. A separate deep scan can be implemented later.
