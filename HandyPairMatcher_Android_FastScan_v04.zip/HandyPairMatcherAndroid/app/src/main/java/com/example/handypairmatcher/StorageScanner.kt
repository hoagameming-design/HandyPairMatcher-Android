package com.example.handypairmatcher

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Optimized read-only scanning of user-selected SAF directories. No broad-storage permission. */
internal object StorageScanner {
    internal data class MediaFile(val uri: Uri, val name: String, val video: Boolean,
                                  val size: Long = -1, val modified: Long = 0)
    internal data class Candidate(val video: MediaFile, val script: MediaFile, val score: Int)
    internal data class Result(val candidates: List<Candidate>, val videos: Int, val scripts: Int,
                               val limited: Boolean, val warnings: List<String>)
    private val videoExtensions = setOf("mp4", "mkv", "mov", "avi", "webm", "m4v")
    private val ignored = setOf("video", "script", "funscript", "final", "copy")
    private const val MAX_ENTRIES = 20000
    private const val MAX_CANDIDATES = 1200
    private const val MAX_METADATA_PAIRS = 900
    private const val MAX_CACHE_ITEMS = 3000

    private data class Named(val file: MediaFile, val tokens: List<String>, val joined: String)
    private fun named(file: MediaFile): Named {
        val tokens = file.name.substringBeforeLast('.').lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
            .split(Regex("\\s+")).filter { it.isNotEmpty() && it !in ignored }
        return Named(file, tokens, tokens.joinToString(""))
    }

    fun scan(context: Context, roots: List<Uri>): Result {
        val resolver = context.contentResolver
        val found = LinkedHashMap<String, MediaFile>()
        val warnings = mutableListOf<String>()
        data class Folder(val root: Uri, val id: String)
        val pending = ArrayDeque<Folder>()
        val visited = HashSet<String>()
        for (root in roots.distinct()) {
            try { pending.add(Folder(root, DocumentsContract.getTreeDocumentId(root))) }
            catch (e: Exception) { warnings.add("Invalid folder: ${e.message}") }
        }
        var seen = 0
        var limited = false
        val projection = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE, Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED)
        while (pending.isNotEmpty()) {
            val (root, folderId) = pending.removeFirst()
            val visitKey = root.authority + ":" + folderId
            if (!visited.add(visitKey)) continue
            try {
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(root, folderId)
                resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(Document.COLUMN_DOCUMENT_ID)
                    val nameCol = cursor.getColumnIndexOrThrow(Document.COLUMN_DISPLAY_NAME)
                    val mimeCol = cursor.getColumnIndexOrThrow(Document.COLUMN_MIME_TYPE)
                    val sizeCol = cursor.getColumnIndex(Document.COLUMN_SIZE)
                    val timeCol = cursor.getColumnIndex(Document.COLUMN_LAST_MODIFIED)
                    while (cursor.moveToNext()) {
                        if (++seen > MAX_ENTRIES) { limited = true; break }
                        val id = cursor.getString(idCol) ?: continue
                        val mime = cursor.getString(mimeCol) ?: ""
                        if (mime == Document.MIME_TYPE_DIR) { pending.add(Folder(root, id)); continue }
                        val name = cursor.getString(nameCol) ?: continue
                        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        val video = ext in videoExtensions
                        if (!video && ext != "funscript") continue
                        val uri = DocumentsContract.buildDocumentUriUsingTree(root, id)
                        val size = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else -1L
                        val modified = if (timeCol >= 0 && !cursor.isNull(timeCol)) cursor.getLong(timeCol) else 0L
                        found[uri.toString()] = MediaFile(uri, name, video, size, modified)
                    }
                }
            } catch (e: Exception) {
                warnings.add("Could not read a folder: ${e.message ?: e.javaClass.simpleName}")
            }
            if (limited) break
        }
        val videos = found.values.filter { it.video }.map(::named)
        val scripts = found.values.filterNot { it.video }.map(::named)
        // Index script tokens once. Avoid rescoring every video against every script.
        val byToken = HashMap<String, MutableList<Int>>()
        scripts.forEachIndexed { index, script ->
            script.tokens.toSet().forEach { token -> byToken.getOrPut(token) { mutableListOf() }.add(index) }
        }
        val metadata = ScanMetadataCache(context)
        val candidates = ArrayList<Candidate>()
        var metadataPairs = 0
        for (video in videos) {
            if (candidates.size >= MAX_CANDIDATES) { limited = true; break }
            val possible = HashSet<Int>()
            video.tokens.forEach { token -> byToken[token]?.let { possible.addAll(it) } }
            // Exact or partially matching compact names may have no matching tokens.
            if (possible.isEmpty() && scripts.size <= 150) {
                scripts.forEachIndexed { index, script ->
                    if (min(video.joined.length, script.joined.length) >= 5 &&
                        (video.joined.contains(script.joined) || script.joined.contains(video.joined))) possible.add(index)
                }
            }
            val shortlisted = possible.asSequence().map { index ->
                val script = scripts[index]
                val base = nameScore(video, script)
                index to base
            }.filter { it.second >= 20 }.sortedByDescending { it.second }.take(5).toList()
            val scored = shortlisted.map { (index, base) ->
                val script = scripts[index]
                val bonus = if (metadataPairs < MAX_METADATA_PAIRS) {
                    metadataPairs++
                    val vd = metadata.duration(video.file, true)
                    val sd = metadata.duration(script.file, false)
                    if (vd != null && sd != null && vd > 0) {
                        when (abs(vd - sd)) {
                            in 0.0..3.0 -> 25
                            in 3.0..10.0 -> 15
                            in 10.0..30.0 -> 7
                            else -> 0
                        }
                    } else 0
                } else 0
                Candidate(video.file, script.file, min(100, base + bonus))
            }.sortedByDescending { it.score }.take(3)
            candidates.addAll(scored.take(MAX_CANDIDATES - candidates.size))
        }
        metadata.save()
        if (limited) warnings.add("Scan limit reached; select smaller folders for complete results.")
        if (metadataPairs >= MAX_METADATA_PAIRS) warnings.add("Timing checks capped to keep scans responsive. Filename ranking remains available.")
        if (videos.isNotEmpty() && scripts.isNotEmpty() && candidates.isEmpty()) warnings.add("No filename-based matches; unrelated names need a separate deep timing scan.")
        return Result(candidates, videos.size, scripts.size, limited, warnings)
    }

    private fun nameScore(a: Named, b: Named): Int {
        if (a.tokens.isEmpty() || b.tokens.isEmpty()) return 0
        if (a.tokens == b.tokens) return 75
        val aa = a.tokens.toSet(); val bb = b.tokens.toSet()
        val overlap = aa.intersect(bb).size
        val union = aa.size + bb.size - overlap
        val substring = if (min(a.joined.length, b.joined.length) >= 5 &&
            (a.joined.contains(b.joined) || b.joined.contains(a.joined))) 20 else 0
        return min(75, if (union == 0) 0 else overlap * 75 / union + substring)
    }

    /** Persist metadata for unchanged files only (size and modification time must be supplied). */
    private class ScanMetadataCache(private val context: Context) {
        private val cache = LinkedHashMap<String, Double?>()
        private val prefs = context.getSharedPreferences("scan_duration_cache_v04", Context.MODE_PRIVATE)
        init {
            try {
                val keys = prefs.all.entries.take(MAX_CACHE_ITEMS)
                keys.forEach { (k, v) -> if (v is Long) cache[k] = java.lang.Double.longBitsToDouble(v) }
            } catch (_: Exception) { }
        }
        private fun key(file: MediaFile, video: Boolean): String? {
            if (file.size < 0 || file.modified <= 0) return null
            return (if (video) "v|" else "s|") + file.uri.toString() + "|" + file.size + "|" + file.modified
        }
        fun duration(file: MediaFile, video: Boolean): Double? {
            val key = key(file, video)
            if (key != null && cache.containsKey(key)) return cache[key]
            val result = if (video) videoSeconds(file.uri) else scriptSeconds(file.uri, file.size)
            if (key != null && cache.size < MAX_CACHE_ITEMS && result != null) cache[key] = result
            return result
        }
        fun save() {
            val edit = prefs.edit().clear()
            cache.entries.take(MAX_CACHE_ITEMS).forEach { (key, duration) ->
                if (duration != null) edit.putLong(key, java.lang.Double.doubleToRawLongBits(duration))
            }
            edit.apply()
        }
        private fun videoSeconds(uri: Uri): Double? = try {
            val r = MediaMetadataRetriever()
            try { r.setDataSource(context, uri)
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull()?.div(1000)
            } finally { r.release() }
        } catch (_: Exception) { null }
        private fun scriptSeconds(uri: Uri, knownSize: Long): Double? = try {
            val size = if (knownSize >= 0) knownSize else context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1
            if (size > 12 * 1024 * 1024) null
            else {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                val actions = JSONObject(raw ?: "{}").optJSONArray("actions")
                if (actions == null || actions.length() == 0) null
                else {
                    var maxMs = 0.0
                    for (i in 0 until actions.length()) {
                        val t = actions.optJSONObject(i)?.optDouble("at", Double.NaN) ?: continue
                        if (t.isFinite() && t >= 0) maxMs = max(maxMs, t)
                    }
                    maxMs / 1000
                }
            }
        } catch (_: Exception) { null }
    }
}
