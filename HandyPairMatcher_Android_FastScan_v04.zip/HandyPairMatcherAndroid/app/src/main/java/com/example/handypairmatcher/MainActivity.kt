package com.example.handypairmatcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.Alignment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private data class PairItem(
    val id: String,
    val video: String,
    val script: String,
    val videoName: String,
    val scriptName: String,
    val verdict: String = "Review",
    val score: Int = 0
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("pairs", MODE_PRIVATE) }
    private fun loadPairs(): List<PairItem> = runCatching {
        val arr = JSONArray(prefs.getString("items", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            PairItem(o.getString("id"), o.getString("video"), o.getString("script"),
                o.getString("videoName"), o.getString("scriptName"),
                o.optString("verdict", "Review"), o.optInt("score", 0))
        }
    }.getOrDefault(emptyList())

    private fun savePairs(items: List<PairItem>) {
        val arr = JSONArray()
        items.forEach { p -> arr.put(JSONObject().apply {
            put("id", p.id); put("video", p.video); put("script", p.script)
            put("videoName", p.videoName); put("scriptName", p.scriptName)
            put("verdict", p.verdict); put("score", p.score)
        }) }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun nameOf(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0) ?: uri.lastPathSegment.orEmpty()
        }
        return uri.lastPathSegment ?: "File"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var items by remember { mutableStateOf(loadPairs()) }
            var videoUri by remember { mutableStateOf<Uri?>(null) }
            var scriptUri by remember { mutableStateOf<Uri?>(null) }
            var tab by remember { mutableStateOf("Review") }
            var sort by remember { mutableStateOf("Score high") }
            var selected by remember { mutableStateOf<PairItem?>(null) }
            var scoreInput by remember { mutableStateOf("0") }
            var videoRoot by remember { mutableStateOf(prefs.getString("videos_root", "") ?: "") }
            var scriptRoot by remember { mutableStateOf(prefs.getString("scripts_root", "") ?: "") }
            var isScanning by remember { mutableStateOf(false) }
            var scanSummary by remember { mutableStateOf("Choose folders to scan. One folder can contain both types.") }
            var minScore by remember { mutableFloatStateOf(0f) }
            var pendingVerdict by remember { mutableStateOf<String?>(null) }
            val context = LocalContext.current
            fun persist(newItems: List<PairItem>) { items = newItems; savePairs(newItems) }
            val videoFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                if (uri != null) {
                    runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    videoRoot = uri.toString()
                    prefs.edit().putString("videos_root", videoRoot).apply()
                }
            }
            val scriptFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                if (uri != null) {
                    runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    scriptRoot = uri.toString()
                    prefs.edit().putString("scripts_root", scriptRoot).apply()
                }
            }
            val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    videoUri = uri
                }
            }
            val scriptPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    scriptUri = uri
                }
            }
            MaterialTheme {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("Handy Pair Matcher", style = MaterialTheme.typography.headlineSmall)
                    Text("Android starter · local files · no files modified", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                    Text("Scan storage", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { videoFolderPicker.launch(null) }) { Text("Videos folder") }
                        Button(onClick = { scriptFolderPicker.launch(null) }) { Text("Scripts folder") }
                    }
                    Text("Videos: " + (if (videoRoot.isBlank()) "Not selected" else "Selected"), style = MaterialTheme.typography.bodySmall)
                    Text("Scripts: " + (if (scriptRoot.isBlank()) "Same as videos folder" else "Selected"), style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !isScanning && (videoRoot.isNotBlank() || scriptRoot.isNotBlank()), onClick = {
                            isScanning = true
                            scanSummary = "Scanning selected folders…"
                            val roots = listOf(videoRoot, scriptRoot).filter(String::isNotBlank).distinct().map(Uri::parse)
                            Thread {
                                try {
                                    val started = SystemClock.elapsedRealtime()
                                    val result = StorageScanner.scan(applicationContext, roots)
                                    val scanSeconds = (SystemClock.elapsedRealtime() - started) / 1000.0
                                    runOnUiThread {
                                        val existing = items.map { it.video + "|" + it.script }.toSet()
                                        val additions = result.candidates.filterNot { it.video.uri.toString() + "|" + it.script.uri.toString() in existing }
                                            .map { PairItem(UUID.randomUUID().toString(), it.video.uri.toString(), it.script.uri.toString(), it.video.name, it.script.name, score = it.score) }
                                        if (additions.isNotEmpty()) persist(items + additions)
                                        scanSummary = "Scanned in ${"%.1f".format(scanSeconds)}s. Found ${result.videos} videos and ${result.scripts} scripts. Added ${additions.size} candidate pairs." +
                                            (if (result.warnings.isNotEmpty()) " " + result.warnings.joinToString(" ") else "")
                                        isScanning = false
                                    }
                                } catch (e: Exception) {
                                    runOnUiThread { scanSummary = "Scan failed: ${e.message}"; isScanning = false }
                                }
                            }.start()
                        }) { Text(if (isScanning) "Scanning…" else "Scan folders") }
                    }
                    Text(scanSummary, style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                    Text("Add a pair manually", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { videoPicker.launch(arrayOf("video/*")) }) { Text("Pick video") }
                        Button(onClick = { scriptPicker.launch(arrayOf("*/*")) }) { Text("Pick .funscript") }
                    }
                    Text(videoUri?.let(::nameOf) ?: "No video selected", maxLines = 1)
                    Text(scriptUri?.let(::nameOf) ?: "No script selected", maxLines = 1)
                    OutlinedTextField(value = scoreInput, onValueChange = { scoreInput = it.filter(Char::isDigit).take(3) },
                        label = { Text("Estimated score (0–100, optional)") }, singleLine = true)
                    Button(enabled = videoUri != null && scriptUri != null, onClick = {
                        val v = videoUri!!; val s = scriptUri!!
                        if (!nameOf(s).endsWith(".funscript", ignoreCase = true)) {
                            Toast.makeText(context, "Choose a .funscript file", Toast.LENGTH_SHORT).show()
                        } else {
                            persist(items + PairItem(UUID.randomUUID().toString(), v.toString(), s.toString(), nameOf(v), nameOf(s),
                                score = (scoreInput.toIntOrNull() ?: 0).coerceIn(0, 100)))
                            videoUri = null; scriptUri = null
                        }
                    }) { Text("Add candidate pair") }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Review", "Correct", "Offset", "Wrong").forEach { value ->
                            FilterChip(selected = tab == value, onClick = { tab = value }, label = { Text(value) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Score high", "Score low").forEach { value ->
                            FilterChip(selected = sort == value, onClick = { sort = value }, label = { Text(value) })
                        }
                    }
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Min score ${minScore.toInt()}", style = MaterialTheme.typography.bodySmall)
                        Slider(value = minScore, onValueChange = { minScore = it }, valueRange = 0f..100f,
                            modifier = Modifier.weight(1f))
                    }
                    val visible = items.filter { it.verdict == tab && it.score >= minScore.toInt() }.let { list ->
                        if (sort == "Score high") list.sortedByDescending { it.score } else list.sortedBy { it.score }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        visible.take(100).forEach { item ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(item.videoName, style = MaterialTheme.typography.titleMedium)
                                    Text(item.scriptName, style = MaterialTheme.typography.bodySmall)
                                    Text("Score ${item.score} · ${item.verdict}")
                                    Button(onClick = { selected = item }) { Text("Open & review") }
                                }
                            }
                        }
                        if (visible.size > 100) Text("Showing first 100 results; increase minimum score to narrow matches.")
                    }
                }
                selected?.let { current ->
                    AlertDialog(
                        onDismissRequest = { selected = null },
                        confirmButton = { TextButton(onClick = { selected = null }) { Text("Close") } },
                        title = { Text("Test pairing") },
                        text = {
                            Column(Modifier.verticalScroll(rememberScrollState())) {
                                Text(current.videoName)
                                Text("Script: ${current.scriptName}")
                                HandyTestPlayer(Uri.parse(current.video), Uri.parse(current.script))
                                listOf("Correct", "Offset", "Wrong").forEach { verdict ->
                                    OutlinedButton(onClick = { pendingVerdict = verdict }) { Text("Mark $verdict") }
                                }
                            }
                        }
                    )
                }
                val verdict = pendingVerdict
                if (verdict != null && selected != null) {
                    AlertDialog(onDismissRequest = { pendingVerdict = null },
                        title = { Text("Confirm $verdict?") },
                        text = { Text("Save this verdict and move the candidate to its tab?") },
                        confirmButton = {
                            Button(onClick = {
                                val id = selected!!.id
                                persist(items.map { if (it.id == id) it.copy(verdict = verdict) else it })
                                pendingVerdict = null; selected = null
                            }) { Text("Yes, save") }
                        }, dismissButton = { TextButton(onClick = { pendingVerdict = null }) { Text("Cancel") } })
                }
            }
        }
    }
}

@Composable
private fun VideoPlayer(uri: Uri) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(210.dp))
}


@Composable
private fun HandyTestPlayer(video: Uri, script: Uri) {
    val context = LocalContext.current
    var key by remember(video, script) { mutableStateOf("") }
    var status by remember(video, script) { mutableStateOf("Loading Handy SDK…") }
    var offsetText by remember(video, script) { mutableStateOf("0") }
    var isPlaying by remember(video, script) { mutableStateOf(false) }
    val controller = remember(video, script) { HandyController(context.applicationContext) { status = it } }
    val player = remember(video) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(video)); prepare() } }
    DisposableEffect(player, controller) {
        onDispose { player.pause(); player.release(); controller.destroy() }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = false } },
            modifier = Modifier.fillMaxWidth().height(210.dp))
        Text("The Handy (original) · Cloud sync", style = MaterialTheme.typography.titleSmall)
        Text("Video stays on phone. Preparing uploads the selected funscript to HandyFeeling.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = key, onValueChange = { key = it.trim().take(80) },
            label = { Text("Handy connection key (not saved)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(enabled = key.isNotBlank(), onClick = { controller.connect(key) }) { Text("Connect") }
            OutlinedButton(onClick = { controller.prepare(context, script) }) { Text("Prepare script") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = {
                player.play(); isPlaying = true
                controller.play(player.currentPosition, offsetText.toIntOrNull()?.coerceIn(-10000, 10000) ?: 0)
            }) { Text("Play + sync") }
            OutlinedButton(onClick = { player.pause(); isPlaying = false; controller.stop() }) { Text("Pause") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = {
                val target = (player.currentPosition - 10000L).coerceAtLeast(0L)
                player.seekTo(target)
                if (isPlaying) controller.play(target, offsetText.toIntOrNull() ?: 0)
            }) { Text("-10s") }
            OutlinedButton(onClick = {
                val target = player.currentPosition + 10000L
                val seekTo = if (player.duration > 0) target.coerceAtMost(player.duration) else target
                player.seekTo(seekTo)
                if (isPlaying) controller.play(seekTo, offsetText.toIntOrNull() ?: 0)
            }) { Text("+10s") }
            OutlinedTextField(offsetText, { offsetText = it.filter { c -> c.isDigit() || c == '-' }.take(6) },
                label = { Text("Offset ms") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Text("Status: $status", style = MaterialTheme.typography.bodySmall)
        Text("Use Pause before changing to another pair. Start with a reduced stroke range on the device.", style = MaterialTheme.typography.bodySmall)
        AndroidView(factory = { controller.webView }, modifier = Modifier.height(1.dp).fillMaxWidth().alpha(0f))
    }
}
