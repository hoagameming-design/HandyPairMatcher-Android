package com.example.handypairmatcher

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONArray

/**
 * Original Handy / firmware 3+ cloud connection through Ohdoki's browser SDK.
 * No key is persisted. The JS engine is private to this app and deliberately has no file access.
 * The video remains local in Android Media3; preparing a script uploads script action data
 * to HandyFeeling's temporary script service.
 */
internal class HandyController(context: Context, private val onStatus: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var destroyed = false
    private val listener = object {
        @JavascriptInterface fun notify(message: String) {
            main.post { if (!destroyed) onStatus(message.take(500)) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    val webView: WebView = WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        addJavascriptInterface(listener, "AndroidStatus")
        webViewClient = WebViewClient()
        loadDataWithBaseURL("https://appassets.androidplatform.net/", HTML, "text/html", "UTF-8", null)
    }

    private fun eval(js: String) {
        main.post { if (!destroyed) webView.evaluateJavascript(js, null) }
    }

    fun connect(key: String) {
        val safeKey = JSONObject.quote(key.trim())
        eval("window.HPM && window.HPM.connect($safeKey);")
    }

    fun prepare(context: Context, uri: Uri) {
        onStatus("Reading script…")
        Thread {
            try {
                val raw = context.contentResolver.openInputStream(uri)?.use { input ->
                    val limit = 12 * 1024 * 1024
                    val out = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    while (true) {
                        val count = input.read(chunk)
                        if (count < 0) break
                        require(out.size() + count <= limit) { "Script exceeds 12 MB limit" }
                        out.write(chunk, 0, count)
                    }
                    out.toString("UTF-8")
                } ?: error("Could not open script")
                val data = JSONObject(raw)
                val actions: JSONArray = data.optJSONArray("actions") ?: error("Missing funscript actions")
                require(actions.length() >= 2) { "Script needs at least 2 actions" }
                for (i in 0 until actions.length()) {
                    val p = actions.optJSONObject(i) ?: error("Invalid action #$i")
                    val at = p.optDouble("at", Double.NaN)
                    val pos = p.optDouble("pos", Double.NaN)
                    require(at.isFinite() && at >= 0 && pos.isFinite() && pos in 0.0..100.0) {
                        "Invalid timestamp or position at action #$i"
                    }
                }
                // Pass the JSON as an object, NOT raw JSON text (the SDK interprets text as CSV).
                eval("window.HPM && window.HPM.prepare(JSON.parse(${JSONObject.quote(raw)}));")
            } catch (e: Exception) {
                main.post { if (!destroyed) onStatus("Script error: ${e.message}") }
            }
        }.start()
    }

    fun play(positionMs: Long, offsetMs: Int) = eval("window.HPM && window.HPM.play(${(positionMs + offsetMs).coerceAtLeast(0)});")
    fun stop() = eval("window.HPM && window.HPM.stop();")
    fun disconnect() = eval("window.HPM && window.HPM.disconnect();")
    fun destroy() {
        if (destroyed) return
        eval("window.HPM && window.HPM.stop();")
        main.post { destroyed = true; webView.removeJavascriptInterface("AndroidStatus"); webView.destroy() }
    }

    companion object {
        // Retry CDN fallback (older desktop reviewer needed this too).
        private const val HTML = """<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"></head><body>
<script>
(function () {
  const sources = [
    'https://cdn.jsdelivr.net/npm/@ohdoki/handy-sdk@2.3.1',
    'https://unpkg.com/@ohdoki/handy-sdk@2.3.1'
  ];
  let next = 0;
  function status(s) { try { AndroidStatus.notify(String(s)); } catch (_) {} }
  function load() {
    if (next >= sources.length) { status('Handy SDK did not load. Check internet.'); return; }
    const tag = document.createElement('script');
    tag.src = sources[next++];
    tag.onload = function () {
      try {
        if (!window.Handy || !Handy.init) throw Error('SDK API unavailable');
        const volatileStore = {};
        const handy = Handy.init({localStorage: {
          getItem: key => Object.prototype.hasOwnProperty.call(volatileStore, key) ? volatileStore[key] : null,
          setItem: (key, value) => { volatileStore[key] = value; },
          removeItem: key => { delete volatileStore[key]; }
        }});
        let connected = false, prepared = false;
        window.HPM = {
          connect: async function (key) {
            try {
              status('Connecting to Handy…');
              const response = await handy.connect(key);
              if (response && response.result === 0) throw Error('Device not online');
              connected = true;
              prepared = false;
              status('Connected. Select Prepare script.');
            } catch (err) { status('Connect failed: ' + (err.message || err)); }
          },
          prepare: async function (script) {
            try {
              if (!connected) throw Error('Connect Handy first');
              if (!script || !Array.isArray(script.actions)) throw Error('Invalid .funscript');
              status('Uploading and preparing script…');
              await handy.setScriptFromData(script);
              prepared = true;
              status('Script ready. Press Play to synchronize.');
            } catch (err) { prepared = false; status('Prepare failed: ' + (err.message || err)); }
          },
          play: async function (timeMs) {
            try {
              if (!connected || !prepared) { status('Connect and prepare a script first.'); return; }
              await handy.hsspPlay(Math.max(0, Math.round(timeMs)));
              status('Handy synchronized at ' + Math.round(timeMs) + 'ms');
            } catch (err) { status('Play failed: ' + (err.message || err)); }
          },
          stop: async function () {
            try { if (connected) await handy.hsspStop(); } catch (err) { status('Stop failed: ' + (err.message || err)); }
          },
          disconnect: async function () {
            try { await handy.hsspStop(); await handy.disconnect(); } catch (_) {}
            connected = false; prepared = false; status('Disconnected');
          }
        };
        status('Handy SDK loaded. Enter your connection key.');
      } catch (e) { load(); }
    };
    tag.onerror = load;
    document.head.appendChild(tag);
  }
  load();
})();
</script></body></html>"""
    }
}
